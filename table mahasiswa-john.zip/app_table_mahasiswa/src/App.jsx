import React from 'react';
import RouteList from './RouteList';

const App = () => {
  return <RouteList />;
};

export default App;
