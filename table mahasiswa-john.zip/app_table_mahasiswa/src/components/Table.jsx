// src/components/Table.jsx
import React from 'react';

const Table = ({ data, onEdit, onDelete }) => {
  return (
    <table className="min-w-full table-auto bg-white rounded-lg">
      <thead>
        <tr className="bg-gray-200">
          <th className="px-4 py-2">NIM</th>
          <th className="px-4 py-2">Nama</th>
          <th className="px-4 py-2">Actions</th>
        </tr>
      </thead>
      <tbody>
        {data.map((student, index) => (
          <tr key={student.nim} className={index % 2 === 0 ? 'bg-gray-100' : ''}>
            <td className="border px-4 py-2">{student.nim}</td>
            <td className="border px-4 py-2">{student.nama}</td>
            <td className="border px-4 py-2">
              <button
                className="bg-yellow-500 text-white px-4 py-2 rounded mr-2"
                onClick={() => onEdit(student)}
              >
                Edit
              </button>
              <button
                className="bg-red-500 text-white px-4 py-2 rounded"
                onClick={() => onDelete(student.nim)}
              >
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
