import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import Mahasiswa from './pages/admin/Mahasiswa';
import AdminLayout from './layouts/AdminLayout';

const router = createBrowserRouter([
  {
    path: '/',
    element: <Login />,
  },
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/register',
    element: <Register />,
  },
  {
    path: '/mahasiswa',
    element: (
      <AdminLayout>
        <Mahasiswa />
      </AdminLayout>
    ),
  },
]);

const RouteList = () => {
  return <RouterProvider router={router} />;
};

export default RouteList;
