// src/layouts/AdminLayout.jsx
import React from 'react';
import Sider from '../components/Sider';

const AdminLayout = ({ children }) => {
  return (
    <div className="flex min-h-screen">
      <Sider />
      <div className="flex-1 flex flex-col">
        <header className="bg-white shadow p-4 flex justify-end">
          <button className="bg-blue-500 text-white px-4 py-2 rounded">Log Out</button>
        </header>
        <main className="flex-grow p-4 bg-blue-50">{children}</main>
        <footer className="bg-indigo-900 text-white p-4 text-center">
          &copy; 2024 Admin Dashboard
        </footer>
      </div>
    </div>
  );
};

export default AdminLayout;
