import React, { useState, useEffect } from "react";
import axios from "axios";
import Button from "../../components/Button";
import Table from "../../components/Table";
import Swal from "sweetalert2";

const Mahasiswa = () => {
  const [students, setStudents] = useState([]); // Data mahasiswa
  const [showModal, setShowModal] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const [currentStudent, setCurrentStudent] = useState({ nim: "", nama: "" });

  // Fungsi untuk mengambil data mahasiswa dari API
  const fetchStudents = async () => {
    try {
      const response = await axios.get("https://jsonplaceholder.typicode.com/users");
      const dataFromAPI = response.data.map((user, index) => ({
        nim: `A11.2022.${String(10000 + index).slice(-5)}`,
        nama: user.name,
      }));
      setStudents(dataFromAPI);
    } catch (error) {
      Swal.fire("Error", "Gagal mengambil data mahasiswa!", "error");
    }
  };

  // Panggil fetchStudents saat komponen pertama kali dirender
  useEffect(() => {
    fetchStudents();
  }, []);

  const handleAdd = () => {
    setCurrentStudent({ nim: "", nama: "" });
    setIsEdit(false);
    setShowModal(true);
  };

  const handleEdit = (student) => {
    setCurrentStudent(student);
    setIsEdit(true);
    setShowModal(true);
  };

  const handleDelete = (nim) => {
    Swal.fire({
      title: "Yakin ingin menghapus?",
      text: "Data yang dihapus tidak dapat dikembalikan!",
      icon: "warning",
      showCancelButton: true,
      confirmButtonColor: "#3085d6",
      cancelButtonColor: "#d33",
      confirmButtonText: "Hapus",
    }).then((result) => {
      if (result.isConfirmed) {
        setStudents(students.filter((student) => student.nim !== nim));
        Swal.fire("Dihapus!", "Mahasiswa telah dihapus.", "success");
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (isEdit) {
      setStudents(
        students.map((s) => (s.nim === currentStudent.nim ? currentStudent : s))
      );
    } else {
      setStudents([...students, currentStudent]);
    }
    setShowModal(false);
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold mb-4">Daftar Mahasiswa</h2>
        <Button
          style="bg-green-500 text-white"
          text="Tambah Mahasiswa"
          onClick={handleAdd}
        />
      </div>
      <div className="bg-white p-6 rounded-lg shadow">
        <Table data={students} onEdit={handleEdit} onDelete={handleDelete} />
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded-lg shadow-lg w-1/3">
            <h2 className="text-xl font-bold mb-4">
              {isEdit ? "Edit Mahasiswa" : "Tambah Mahasiswa"}
            </h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label htmlFor="nim" className="block text-gray-700">
                  NIM:
                </label>
                <input
                  type="text"
                  id="nim"
                  value={currentStudent.nim}
                  onChange={(e) =>
                    setCurrentStudent({
                      ...currentStudent,
                      nim: e.target.value,
                    })
                  }
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                  disabled={isEdit} // Disable NIM editing in edit mode
                />
              </div>
              <div className="mb-4">
                <label htmlFor="nama" className="block text-gray-700">
                  Nama:
                </label>
                <input
                  type="text"
                  id="nama"
                  value={currentStudent.nama}
                  onChange={(e) =>
                    setCurrentStudent({
                      ...currentStudent,
                      nama: e.target.value,
                    })
                  }
                  className="w-full px-4 py-2 border rounded-lg"
                  required
                />
              </div>
              <div className="flex justify-end">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="bg-gray-500 text-white px-4 py-2 rounded mr-2"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="bg-green-500 text-white px-4 py-2 rounded"
                >
                  Simpan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Mahasiswa;
